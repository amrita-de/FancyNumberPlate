import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
import os

# Define parameters
IMG_SIZE = (224, 224)  # Resize images to 224x224
BATCH_SIZE = 32  # Number of images processed at once

# Specify the path to your dataset
dataset_path = r'C:/FancyNumDataset'  # Update with your dataset path

# Create ImageDataGenerator for training and validation
train_datagen = ImageDataGenerator(preprocessing_function=preprocess_input,  # MobileNetV2 specific scaling
                                   rotation_range=30,  # Data augmentation
                                   width_shift_range=0.2,
                                   height_shift_range=0.2,
                                   shear_range=0.2,
                                   zoom_range=0.2,
                                   horizontal_flip=True,
                                   fill_mode='nearest',
                                   validation_split=0.2)  # Split dataset into training and validation sets

# Load training data
train_generator = train_datagen.flow_from_directory(
    dataset_path,  # Directory containing images
    target_size=IMG_SIZE,  # Resize images to 224x224
    batch_size=BATCH_SIZE,
    class_mode='categorical',  # For multi-class classification
    subset='training'  # Use this for training data
)

# Load validation data
validation_generator = train_datagen.flow_from_directory(
    dataset_path,  # Same directory for validation
    target_size=IMG_SIZE,  # Resize images to 224x224
    batch_size=BATCH_SIZE,
    class_mode='categorical',  # Same class mode
    subset='validation'  # Use this for validation data
)

# Check the loaded images and labels
for images, labels in train_generator:
    print(f'Image batch shape: {images.shape}')
    print(f'Label batch shape: {labels.shape}')
    break
