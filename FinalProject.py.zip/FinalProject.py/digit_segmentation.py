import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import os

# Load the pre-trained model
model = load_model(r'C:\FinalProject.py\four_digit_model.keras')  # Use raw string for path

# Class names mapping based on directories in your dataset
# Assuming fancyno0 corresponds to 0, fancyno1 to 1, ..., fancyno9 to 9
class_names = [str(i) for i in range(10)]  # Mapping from class index to digit

# Function to preprocess each digit image for prediction
def preprocess_digit(digit_image):
    digit_image_resized = cv2.resize(digit_image, (224, 224))
    digit_image_normalized = digit_image_resized / 255.0
    if digit_image_normalized.ndim == 2:
        digit_image_normalized = np.stack((digit_image_normalized,) * 3, axis=-1)
    digit_image_batch = np.expand_dims(digit_image_normalized, axis=0)
    return digit_image_batch

# Function to detect digit boundaries using CCL
def detect_digit_boundaries_and_ccl(image):
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Adaptive thresholding to get a binary image
    thresholded = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                        cv2.THRESH_BINARY_INV, 11, 2)

    # Find connected components (CCL)
    num_labels, labels_im = cv2.connectedComponents(thresholded)
    
    # Create a list for the contours of the detected digits
    digit_contours = []
    
    # Loop through each label to find the bounding boxes
    for label in range(1, num_labels):  # Start from 1 to skip the background label
        # Create a mask for the connected component
        mask = np.zeros_like(gray)
        mask[labels_im == label] = 255
        
        # Find contours of the component
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            if cv2.contourArea(contour) > 100:  # Filter small contours by area
                digit_contours.append(contour)
                
                # Draw the contours on the original image
                cv2.drawContours(image, [contour], -1, (0, 255, 0), 2)

    # Show the image with detected boundaries
    cv2.imshow('Digit Boundaries with CCL', image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    return digit_contours

# Function to save segmented digits
def save_segmented_digits(digit_contours, original_image, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    digit_images = []
    
    # Sort the contours based on their x-coordinate (left to right)
    digit_contours = sorted(digit_contours, key=lambda contour: cv2.boundingRect(contour)[0])
    
    for i, contour in enumerate(digit_contours):
        # Create a mask for each digit
        mask = np.zeros_like(original_image)
        cv2.drawContours(mask, [contour], -1, (255, 255, 255), thickness=cv2.FILLED)

        # Extract the digit from the original image using the mask
        digit_image = cv2.bitwise_and(original_image, mask)
        x, y, w, h = cv2.boundingRect(contour)
        digit_crop = digit_image[y:y+h, x:x+w]  # Crop the digit
        
        # Save the digit to the output folder with sorted order
        digit_image_path = os.path.join(output_folder, f'digit_{i}.png')
        cv2.imwrite(digit_image_path, digit_crop)

        digit_images.append(digit_crop)  # Append the cropped image to the list

    return digit_images

# Function to predict each digit in the segmented number plate
def predict_digits(digit_images):
    predictions = []
    for digit_image in digit_images:
        # Preprocess the digit and predict the class
        preprocessed_digit = preprocess_digit(digit_image)
        if preprocessed_digit is not None and preprocessed_digit.shape[1:3] == (224, 224):
            prediction = model.predict(preprocessed_digit)
            predicted_class_index = np.argmax(prediction, axis=1)[0]
            predicted_digit = class_names[predicted_class_index]  # Map to digit string
            predictions.append(predicted_digit)  # Store digit as a string
        else:
            predictions.append("Unknown")

    return predictions

# Main function
if __name__ == '__main__':
    # Path to number plate image
    image_path = r'C:\dada2 (1).png'  # Replace with your image path
    output_folder = r'C:\SegmentedDigits'  # Folder to save segmented digits

    # Read the image
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not read image. Please check the path.")
    else:
        # Step 1: Detect the digit boundaries using CCL
        digit_contours = detect_digit_boundaries_and_ccl(image)

        # Step 2: Save the segmented digits
        digit_images = save_segmented_digits(digit_contours, image, output_folder)

        # Step 3: Predict each digit based on the segmented images
        predictions = predict_digits(digit_images)

        # Output the result
        predicted_number = ''.join(predictions)  # Join the digits to form the number plate
        print(f'Predicted number plate: {predicted_number}')
